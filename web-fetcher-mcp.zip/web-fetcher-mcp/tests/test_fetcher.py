import pytest

from src.services.fetcher import WebFetcher


@pytest.mark.asyncio
async def test_fetch_example_com():
    fetcher = WebFetcher()
    result = await fetcher.fetch("https://example.com/")

    assert result.status_code == 200
    assert "Example Domain" in result.content
