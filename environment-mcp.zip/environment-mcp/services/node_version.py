def node_version_available() -> bool:
    return True
