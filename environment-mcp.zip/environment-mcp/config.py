from pathlib import Path
import os

DEFAULT_PROJECT_PATH = Path.cwd()

SAFE_COMMANDS = {
    "python": ["python", "--version"],
    "node": ["node", "--version"],
    "npm": ["npm", "--version"],
    "java": ["java", "--version"],
    "git": ["git", "--version"],
    "docker": ["docker", "--version"],
}

SECRET_PATTERNS = (
    "KEY", "TOKEN", "SECRET", "PASSWORD", "PASSWD",
    "CREDENTIAL", "PRIVATE", "AUTH"
)

PYTHON_FRAMEWORKS = {
    "fastapi": "FastAPI",
    "flask": "Flask",
    "django": "Django",
    "torch": "PyTorch",
    "pytorch": "PyTorch",
    "tensorflow": "TensorFlow",
    "langchain": "LangChain",
    "pydantic": "Pydantic",
}

NODE_FRAMEWORKS = {
    "react": "React",
    "next": "Next.js",
    "vue": "Vue",
    "@angular/core": "Angular",
    "express": "Express",
    "vite": "Vite",
    "@nestjs/core": "NestJS",
}


def resolve_project_path(path: str | None) -> Path:
    raw = Path(path).expanduser() if path else DEFAULT_PROJECT_PATH
    return raw.resolve(strict=False)


def is_secret_name(name: str) -> bool:
    upper = name.upper()
    return any(pattern in upper for pattern in SECRET_PATTERNS)
