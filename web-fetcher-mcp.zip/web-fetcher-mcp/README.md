# Web Fetcher MCP

Reusable MCP server for web search, fetching, scraping, link extraction, and robots.txt-aware crawling.

## Tools

- `search_web`
- `check_robots_txt`
- `fetch_url`
- `scrape_page`
- `extract_links`
- `fetch_multiple`

## Setup

```powershell
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## Test with MCP Inspector

```powershell
mcp dev src/server.py
```

## Run directly

```powershell
python src/server.py
```

## Smoke test

```powershell
python smoke_test.py
```

## Tests

```powershell
pytest
```

## Environment variables

```text
WEB_FETCHER_USER_AGENT=WebFetcherMCP/1.0
WEB_FETCHER_TIMEOUT=20
WEB_FETCHER_MAX_CONTENT_BYTES=2097152
WEB_FETCHER_MAX_LINKS=500
WEB_FETCHER_MAX_CONCURRENT=5
WEB_FETCHER_BLOCK_PRIVATE_NETWORKS=true
```

## Behavior

`fetch_url`, `scrape_page`, `extract_links`, and `fetch_multiple` automatically check robots.txt.

Search returns URLs but does not automatically fetch them. The AI application decides which search results to inspect.

The server limits response size and blocks localhost/private-network targets by default to reduce SSRF risk.

## Example workflow

```text
User
  |
  v
AI Agent
  |
  +--> search_web
  |       |
  |       +--> result URLs
  |
  +--> scrape_page
  |       |
  |       +--> robots.txt check
  |       +--> webpage
  |
  +--> fetch_multiple
          |
          +--> robots-aware concurrent fetches
```
