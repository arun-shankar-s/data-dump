"""
Web investigation agent.

For this MVP the agent explicitly invokes the Fetch MCP tool (via
FetchMcpClient) and then hands the retrieved content to the LLM for
analysis. The two responsibilities -- "get content via MCP" and
"analyze content" -- are kept as separate, injectable collaborators so
this can evolve later into a loop where the LLM itself decides when to
call the MCP tool, without rewriting the MCP client or this class's
public interface.
"""
from __future__ import annotations

import asyncio
import logging

from backend.agent.llm_client import LLMClient, get_llm_client
from backend.agent.prompts import build_analysis_prompt
from backend.config import settings
from backend.mcp.fetch_client import FetchMcpClient, McpFetchError, McpToolNotFoundError

logger = logging.getLogger("mcp_fetch_agent.agent")


class AgentError(Exception):
    pass


class InvestigationAgent:
    def __init__(self, mcp_client: FetchMcpClient | None = None, llm_client: LLMClient | None = None) -> None:
        self.mcp_client = mcp_client or FetchMcpClient()
        self.llm_client = llm_client or get_llm_client()

    async def investigate(self, url: str) -> dict:
        logger.info("agent_investigation_started url=%s", url)

        try:
            fetch_result = await asyncio.wait_for(
                self.mcp_client.fetch(url), timeout=settings.FETCH_TIMEOUT + 5
            )
        except McpToolNotFoundError as exc:
            raise AgentError(str(exc)) from exc
        except McpFetchError as exc:
            raise AgentError(str(exc)) from exc
        except asyncio.TimeoutError as exc:
            raise AgentError("Fetching the page via MCP timed out") from exc

        logger.info("agent_content_received length=%d", len(fetch_result.content))

        analysis = ""
        llm_configured = settings.llm_configured
        if llm_configured:
            logger.info("agent_analysis_started")
            try:
                prompt = build_analysis_prompt(url, fetch_result.content)
                analysis = await asyncio.wait_for(
                    self.llm_client.analyze(prompt), timeout=settings.AGENT_TIMEOUT
                )
                logger.info("agent_analysis_completed")
            except asyncio.TimeoutError as exc:
                raise AgentError("AI analysis timed out") from exc
            except Exception as exc:  # noqa: BLE001
                logger.exception("agent_analysis_failed")
                raise AgentError(f"AI analysis failed: {exc}") from exc

        return {
            "content": fetch_result.content,
            "analysis": analysis,
            "mcp_tool": fetch_result.tool_name,
            "llm_configured": llm_configured,
        }
