from services.system_service import get_system_info

def test_system_info():
    info = get_system_info()
    assert info.os
    assert info.architecture
    assert info.python_version
