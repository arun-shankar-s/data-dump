import json
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

from app.config import settings

class MCPClientError(RuntimeError):
    pass

def extract_result(result: Any) -> Any:
    data = getattr(result, "structuredContent", None)
    if data is None:
        data = getattr(result, "structured_content", None)
    if data is not None:
        return data

    texts = []
    for item in getattr(result, "content", []) or []:
        text = getattr(item, "text", None)
        if text is not None:
            texts.append(text)

    if len(texts) == 1:
        try:
            return json.loads(texts[0])
        except json.JSONDecodeError:
            return texts[0]
    return texts

class WebFetcherMCPClient:
    def _params(self):
        if not settings.mcp_server_path:
            raise MCPClientError(
                "MCP_SERVER_PATH is not configured."
            )

        server_path = Path(settings.mcp_server_path)

        if not server_path.exists():
            raise MCPClientError(
                f"MCP server not found: {server_path}"
            )

        project_root = server_path.parent.parent

        return StdioServerParameters(
            command=settings.mcp_python or "python",
            args=["-m", "src.server"],
            cwd=str(project_root),
        )

    @asynccontextmanager
    async def session(self):
        async with stdio_client(self._params()) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                yield session

    async def list_tools(self):
        async with self.session() as session:
            result = await session.list_tools()
            return [tool.name for tool in result.tools]

    async def call_tool(self, name: str, arguments: dict):
        async with self.session() as session:
            result = await session.call_tool(name, arguments)
            if getattr(result, "isError", False) or getattr(result, "is_error", False):
                raise MCPClientError(f"MCP tool '{name}' returned an error.")
            return extract_result(result)
