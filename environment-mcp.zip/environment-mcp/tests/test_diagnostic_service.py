from services.diagnostic_service import diagnose_environment

def test_invalid_path():
    result = diagnose_environment("this-path-should-not-exist-123456")
    assert result.success is False
    assert result.healthy is False
