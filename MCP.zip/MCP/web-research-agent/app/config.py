import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

@dataclass(frozen=True)
class Settings:
    mcp_server_path: str = os.getenv("MCP_SERVER_PATH", "")
    mcp_python: str = os.getenv("MCP_PYTHON", "")
    max_search_results: int = int(os.getenv("MAX_SEARCH_RESULTS", "5"))
    max_source_chars: int = int(os.getenv("MAX_SOURCE_CHARS", "6000"))
    max_total_research_chars: int = int(os.getenv("MAX_TOTAL_RESEARCH_CHARS", "20000"))
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    openai_base_url: str = os.getenv(
        "OPENAI_BASE_URL",
        "http://10.10.207.13:8083/v1",
    )
    openai_model: str = os.getenv(
        "OPENAI_MODEL",
        "gemma-4-31B",
    )

settings = Settings()
