import subprocess
from services.git_service import get_git_info

def test_non_git_directory(tmp_path):
    info = get_git_info(str(tmp_path))
    assert info.is_repository is False

def test_git_repository(tmp_path):
    subprocess.run(["git", "init"], cwd=tmp_path, check=True, capture_output=True)
    info = get_git_info(str(tmp_path))
    assert info.is_repository is True
    assert info.repository_root
