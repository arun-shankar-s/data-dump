import asyncio

from src.services.search import WebSearch


def test_search_returns_list():
    search = WebSearch()

    results = asyncio.run(
        asyncio.to_thread(
            search.search,
            "Python programming language",
            3,
        )
    )

    assert isinstance(results, list)
    assert len(results) <= 3

    if results:
        assert "url" in results[0]
