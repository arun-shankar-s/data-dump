from types import SimpleNamespace
from unittest.mock import AsyncMock, patch

import pytest

from backend.mcp.fetch_client import FetchMcpClient, McpFetchError, McpToolNotFoundError


def _text_block(text):
    return SimpleNamespace(type="text", text=text)


class _FakeSession:
    def __init__(self, tool_names, call_result_text="Hello world", is_error=False):
        self._tool_names = tool_names
        self._call_result_text = call_result_text
        self._is_error = is_error

    async def __aenter__(self):
        return self

    async def __aexit__(self, *a):
        return False

    async def initialize(self):
        return None

    async def list_tools(self):
        return SimpleNamespace(tools=[SimpleNamespace(name=n) for n in self._tool_names])

    async def call_tool(self, name, args):
        return SimpleNamespace(
            isError=self._is_error,
            content=[_text_block(self._call_result_text)],
        )


class _FakeStdioCtx:
    def __init__(self):
        pass

    async def __aenter__(self):
        return (AsyncMock(), AsyncMock())

    async def __aexit__(self, *a):
        return False


@pytest.mark.asyncio
async def test_fetch_success():
    client = FetchMcpClient()
    fake_session = _FakeSession(tool_names=["fetch"], call_result_text="Example Domain content")

    with patch("backend.mcp.fetch_client.stdio_client", return_value=_FakeStdioCtx()), patch(
        "backend.mcp.fetch_client.ClientSession", return_value=fake_session
    ):
        result = await client.fetch("https://example.com")

    assert result.content == "Example Domain content"
    assert result.tool_name == "fetch"


@pytest.mark.asyncio
async def test_fetch_tool_missing_raises():
    client = FetchMcpClient()
    fake_session = _FakeSession(tool_names=["some_other_tool"])

    with patch("backend.mcp.fetch_client.stdio_client", return_value=_FakeStdioCtx()), patch(
        "backend.mcp.fetch_client.ClientSession", return_value=fake_session
    ):
        with pytest.raises(McpToolNotFoundError):
            await client.fetch("https://example.com")


@pytest.mark.asyncio
async def test_fetch_tool_error_result_raises():
    client = FetchMcpClient()
    fake_session = _FakeSession(tool_names=["fetch"], is_error=True)

    with patch("backend.mcp.fetch_client.stdio_client", return_value=_FakeStdioCtx()), patch(
        "backend.mcp.fetch_client.ClientSession", return_value=fake_session
    ):
        with pytest.raises(McpFetchError):
            await client.fetch("https://example.com")


@pytest.mark.asyncio
async def test_transport_failure_wrapped_as_mcp_fetch_error():
    client = FetchMcpClient()

    class _BrokenCtx:
        async def __aenter__(self):
            raise RuntimeError("process failed to start")

        async def __aexit__(self, *a):
            return False

    with patch("backend.mcp.fetch_client.stdio_client", return_value=_BrokenCtx()):
        with pytest.raises(McpFetchError):
            await client.fetch("https://example.com")
