from __future__ import annotations

import subprocess
from pathlib import Path

from config import resolve_project_path
from models.environment_models import GitInfo


def _git(path: Path, args: list[str]) -> tuple[bool, str]:
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=path,
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
            shell=False,
        )
        return result.returncode == 0, (result.stdout or "").strip()
    except (OSError, subprocess.SubprocessError):
        return False, ""


def get_git_info(path: str | None = None) -> GitInfo:
    project_path = resolve_project_path(path)
    if not project_path.exists():
        return GitInfo(is_repository=False, error="Project path does not exist.")

    ok, root = _git(project_path, ["rev-parse", "--show-toplevel"])
    if not ok:
        return GitInfo(is_repository=False)

    _, branch = _git(project_path, ["branch", "--show-current"])
    _, commit = _git(project_path, ["rev-parse", "--short", "HEAD"])
    ok, status = _git(project_path, ["status", "--porcelain"])
    if not ok:
        return GitInfo(is_repository=True, repository_root=root, error="Unable to read Git status.")

    modified: list[str] = []
    untracked: list[str] = []
    staged: list[str] = []
    for line in status.splitlines():
        if len(line) < 3:
            continue
        index_status, worktree_status = line[0], line[1]
        filename = line[3:]
        if index_status == "?" and worktree_status == "?":
            untracked.append(filename)
        else:
            if index_status not in (" ", "?"):
                staged.append(filename)
            if worktree_status not in (" ", "?"):
                modified.append(filename)

    return GitInfo(
        is_repository=True,
        repository_root=root,
        current_branch=branch or None,
        current_commit=commit or None,
        clean=not bool(status),
        modified_files=modified,
        untracked_files=untracked,
        staged_files=staged,
    )
