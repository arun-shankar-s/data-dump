from services.project_service import get_project_info


def register(mcp):
    @mcp.tool()
    def get_project_info(path: str | None = None):
        """Inspect a project directory using deterministic, read-only filesystem checks."""
        return get_project_info(path)
