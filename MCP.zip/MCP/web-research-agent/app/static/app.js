const q=document.getElementById("query");
const n=document.getElementById("sources");
const b=document.getElementById("research");
const s=document.getElementById("status");
const r=document.getElementById("results");
const a=document.getElementById("answer");
const l=document.getElementById("sources-list");

b.onclick=async()=>{
  const query=q.value.trim();
  if(!query){s.textContent="Enter a research question.";return}
  b.disabled=true;
  r.classList.add("hidden");
  s.textContent="Searching and inspecting sources through MCP...";
  try{
    const res=await fetch("/api/research",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({query,max_sources:Number(n.value)})
    });
    const data=await res.json();
    if(!res.ok)throw Error(data.detail||"Research failed.");
    a.textContent=data.answer;
    l.innerHTML="";
    for(const x of data.sources){
      const d=document.createElement("div");
      d.className="source";
      const title=document.createElement("strong");
      const link=document.createElement("a");
      link.target="_blank";
      link.rel="noopener";
      link.href=x.url;
      link.textContent=x.title||x.url;
      title.appendChild(link);
      const url=document.createElement("div");
      url.className="url";
      url.textContent=x.url;
      const snippet=document.createElement("div");
      snippet.className="snippet";
      snippet.textContent=x.snippet||"";
      d.append(title,url,snippet);
      l.appendChild(d);
    }
    r.classList.remove("hidden");
    s.textContent=`Used ${data.scraped_sources_count} sources from ${data.search_results_count} search results.`;
  }catch(e){s.textContent=e.message}
  finally{b.disabled=false}
};
