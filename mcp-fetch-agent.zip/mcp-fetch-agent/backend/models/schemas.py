from pydantic import BaseModel, HttpUrl


class InvestigateRequest(BaseModel):
    url: HttpUrl


class InvestigateResponse(BaseModel):
    success: bool
    url: str
    content: str | None = None
    analysis: str | None = None
    mcp_tool: str = "fetch"
    error: str | None = None
    llm_configured: bool = True


class HealthResponse(BaseModel):
    status: str


class McpStatusResponse(BaseModel):
    status: str
    tools: list[str] = []
    detail: str | None = None
