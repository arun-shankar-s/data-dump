# Workflow State Agent

## Purpose
Model the VECV S&OP planning workflow as explicit database states, transitions, ownership, locking, and audit events.

## Primary Workflow

Dealer
→ CSM/ASM
→ RSM
→ VH
→ ISO
→ PPC

Other channels:
- COCO CSM/ASM → COCO RBH → COCO VH
- IB Country Head → IB Regional Head → IB Global Head
- IS single-owner
- NPI single-owner
- EPS standalone

## Primary Responsibilities
- Define workflow states.
- Define valid state transitions.
- Define who can edit at each state.
- Define lock behavior.
- Define cutoff behavior.
- Model S&OP-1A and S&OP-1B separately.
- Define audit events.

## State Structure

| State | Owner | Editable | Visible | Transition Trigger | Next State | Lock | Audit Event |
|---|---|---|---|---|---|---|---|

## Confirmed Cut-offs
- Dealer: 15th midnight.
- CSM/ASM: 16th midnight.
- RSM: 17th midnight.
- VH: 18th midnight.
- ISO: 19th–20th.

If a cutoff falls on a public holiday, the documented rule moves it to the prior working day.

## Rules
1. A locked tier becomes read-only.
2. Higher tiers receive lower-tier data as reference.
3. RSM/VH/ISO overrides require a reason.
4. ISO release requires all VH layers submitted.
5. S&OP-1B allows revision for RSM, VH, and ISO only.
6. Unconfirmed default/auto-submit behavior must remain flagged.
7. Preserve immutable audit history.

## Outputs
- State machine.
- Transition matrix.
- Role/state permission matrix.
- Locking model.
- Cutoff model.
- Audit-event model.
- Workflow gaps/open items.

## Do Not
- Treat UI button state as the workflow definition.
- Allow impossible transitions.
- Delete previous cycle/revision history.
- Invent approval layers.
