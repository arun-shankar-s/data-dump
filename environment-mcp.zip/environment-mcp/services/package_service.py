from __future__ import annotations

import json
from importlib import metadata
from pathlib import Path

from config import resolve_project_path
from models.environment_models import NodePackageInfo, PythonPackageInfo, PythonPackagesResponse


def get_python_packages(search: str | None = None) -> PythonPackagesResponse:
    packages = []
    needle = search.lower().strip() if search else None
    for dist in metadata.distributions():
        name = dist.metadata.get("Name") or dist.name
        version = dist.version
        if needle and needle not in name.lower():
            continue
        packages.append(PythonPackageInfo(name=name, version=version))
    packages.sort(key=lambda item: item.name.lower())
    return PythonPackagesResponse(packages=packages)


def get_node_packages(path: str | None = None) -> NodePackageInfo:
    project_path = resolve_project_path(path)
    package_json = project_path / "package.json"
    if not package_json.exists():
        return NodePackageInfo(success=False, error="package.json does not exist.")
    try:
        data = json.loads(package_json.read_text(encoding="utf-8"))
        return NodePackageInfo(
            dependencies=data.get("dependencies", {}) or {},
            dev_dependencies=data.get("devDependencies", {}) or {},
        )
    except (OSError, json.JSONDecodeError, TypeError, ValueError) as exc:
        return NodePackageInfo(success=False, error=f"Unable to parse package.json: {exc}")
