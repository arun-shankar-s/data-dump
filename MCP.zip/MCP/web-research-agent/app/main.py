from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app.config import settings
from app.models import ResearchRequest, ResearchResponse
from app.services.mcp_client import MCPClientError, WebFetcherMCPClient
from app.services.research_agent import ResearchAgent

BASE = Path(__file__).resolve().parent
app = FastAPI(title="Web Research Agent", version="0.1.0")
app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")

@app.get("/")
async def index():
    return FileResponse(BASE / "static" / "index.html")

@app.get("/api/health")
async def health():
    result = {
        "status": "ok",
        "mcp_server_configured": bool(settings.mcp_server_path),
        "ollama_model": settings.ollama_model,
    }
    if settings.mcp_server_path:
        try:
            result["mcp_tools"] = await WebFetcherMCPClient().list_tools()
            result["mcp_status"] = "connected"
        except Exception as exc:
            result["mcp_status"] = "error"
            result["mcp_error"] = str(exc)
    return result

@app.post("/api/research", response_model=ResearchResponse)
async def research(request: ResearchRequest):
    try:
        return await ResearchAgent().research(
            request.query,
            request.max_sources,
        )
    except MCPClientError as exc:
        raise HTTPException(502, f"MCP error: {exc}") from exc
    except Exception as exc:
        raise HTTPException(500, str(exc)) from exc
