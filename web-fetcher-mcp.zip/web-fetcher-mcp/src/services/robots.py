from urllib.parse import urlparse
from urllib.robotparser import RobotFileParser

import httpx

from src.config import settings
from src.services.security import validate_url


class RobotsChecker:
    def __init__(self, user_agent: str | None = None, timeout: float | None = None):
        self.user_agent = user_agent or settings.user_agent
        self.timeout = timeout or settings.timeout

    async def check(self, url: str) -> dict:
        url = validate_url(url, settings.block_private_networks)
        parsed = urlparse(url)
        robots_url = f"{parsed.scheme}://{parsed.netloc}/robots.txt"

        try:
            async with httpx.AsyncClient(
                timeout=self.timeout,
                follow_redirects=True,
                headers={"User-Agent": self.user_agent},
            ) as client:
                response = await client.get(robots_url)

            if response.status_code == 404:
                return {
                    "allowed": True,
                    "robots_url": robots_url,
                    "status_code": 404,
                    "reason": "robots.txt not found",
                    "crawl_delay": None,
                    "sitemaps": [],
                }

            if response.status_code in {401, 403}:
                return {
                    "allowed": False,
                    "robots_url": robots_url,
                    "status_code": response.status_code,
                    "reason": "robots.txt denied access",
                    "crawl_delay": None,
                    "sitemaps": [],
                }

            if response.status_code >= 500:
                return {
                    "allowed": False,
                    "robots_url": robots_url,
                    "status_code": response.status_code,
                    "reason": "robots.txt server error; fetch denied",
                    "crawl_delay": None,
                    "sitemaps": [],
                }

            parser = RobotFileParser()
            parser.set_url(robots_url)
            parser.parse(response.text.splitlines())

            allowed = parser.can_fetch(self.user_agent, url)

            return {
                "allowed": allowed,
                "robots_url": robots_url,
                "status_code": response.status_code,
                "reason": (
                    "Allowed by robots.txt"
                    if allowed
                    else "Blocked by robots.txt"
                ),
                "crawl_delay": parser.crawl_delay(self.user_agent),
                "sitemaps": parser.site_maps() or [],
            }

        except httpx.HTTPError as exc:
            return {
                "allowed": False,
                "robots_url": robots_url,
                "status_code": None,
                "reason": f"Failed to retrieve robots.txt: {exc}",
                "crawl_delay": None,
                "sitemaps": [],
            }
