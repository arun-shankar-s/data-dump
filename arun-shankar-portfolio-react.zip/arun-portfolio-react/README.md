# Arun Shankar Portfolio

React + Vite implementation of the supplied static portfolio reference.

## Run

```bash
npm install
npm run dev
```

Then open the localhost URL printed by Vite.

## Build

```bash
npm run build
```

The design intentionally uses the reference CSS directly as the visual baseline. Replace the CSS-drawn placeholders with real assets later.
