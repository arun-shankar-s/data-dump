from mcp.server.fastmcp import FastMCP

from tools.system_tools import register as register_system
from tools.runtime_tools import register as register_runtime
from tools.project_tools import register as register_project
from tools.package_tools import register as register_packages
from tools.git_tools import register as register_git
from tools.diagnostic_tools import register as register_diagnostics

mcp = FastMCP("Environment MCP")

register_system(mcp)
register_runtime(mcp)
register_project(mcp)
register_packages(mcp)
register_git(mcp)
register_diagnostics(mcp)


if __name__ == "__main__":
    mcp.run()
