"""
URL validation with SSRF protections.

This module decides whether a URL is safe to hand to the Fetch MCP
server. The Fetch MCP server itself will happily retrieve any URL it
is given, including internal/private network addresses, so this
application is responsible for enforcing that only public web pages
can be requested.

Design: fail closed. Any ambiguity, DNS failure, or unrecognized
address shape results in rejection.
"""
from __future__ import annotations

import ipaddress
import socket
from dataclasses import dataclass
from urllib.parse import urlparse

ALLOWED_SCHEMES = {"http", "https"}

# Hostnames that resolve "internally" by convention rather than by IP.
BLOCKED_HOSTNAME_SUBSTRINGS = (
    "localhost",
    ".local",
    ".internal",
    ".corp",
    ".lan",
    ".home",
    "metadata.google.internal",
)

BLOCKED_EXACT_HOSTNAMES = {
    "localhost",
    "localhost.localdomain",
    "ip6-localhost",
    "0.0.0.0",
}


@dataclass
class ValidationResult:
    is_valid: bool
    reason: str | None = None
    resolved_ips: list[str] | None = None


def _is_blocked_ip(ip_str: str) -> bool:
    """Return True if the given IP address must not be fetched."""
    try:
        ip = ipaddress.ip_address(ip_str)
    except ValueError:
        # Cannot parse -- fail closed.
        return True

    if ip.is_loopback:
        return True
    if ip.is_private:
        return True
    if ip.is_link_local:
        return True
    if ip.is_reserved:
        return True
    if ip.is_multicast:
        return True
    if ip.is_unspecified:
        return True

    # Cloud metadata endpoints (AWS/GCP/Azure) live at 169.254.169.254,
    # already caught by is_link_local, but call it out explicitly.
    if ip_str == "169.254.169.254":
        return True

    return False


def validate_url(url: str) -> ValidationResult:
    """
    Validate that `url` is a well-formed public http/https URL that is
    safe to pass to the Fetch MCP server.
    """
    if not url or not isinstance(url, str):
        return ValidationResult(False, "URL is empty or not a string")

    try:
        parsed = urlparse(url.strip())
    except Exception:
        return ValidationResult(False, "Malformed URL")

    if parsed.scheme.lower() not in ALLOWED_SCHEMES:
        return ValidationResult(False, f"Scheme '{parsed.scheme}' is not allowed; use http or https")

    hostname = parsed.hostname
    if not hostname:
        return ValidationResult(False, "URL has no hostname")

    hostname_lower = hostname.lower()

    if hostname_lower in BLOCKED_EXACT_HOSTNAMES:
        return ValidationResult(False, f"Hostname '{hostname}' is blocked")

    for fragment in BLOCKED_HOSTNAME_SUBSTRINGS:
        if fragment in hostname_lower:
            return ValidationResult(False, f"Hostname '{hostname}' looks internal and is blocked")

    # If the hostname is itself a literal IP address, validate it directly.
    try:
        literal_ip = ipaddress.ip_address(hostname_lower)
    except ValueError:
        literal_ip = None

    if literal_ip is not None:
        if _is_blocked_ip(str(literal_ip)):
            return ValidationResult(False, f"IP address '{literal_ip}' is not a public address")
        return ValidationResult(True, resolved_ips=[str(literal_ip)])

    # Otherwise resolve the hostname and check every returned address.
    # This prevents "DNS rebinding" style bypasses where a public-looking
    # hostname resolves to a private/internal IP.
    try:
        addr_infos = socket.getaddrinfo(hostname, None)
    except socket.gaierror:
        return ValidationResult(False, f"Could not resolve hostname '{hostname}'")
    except Exception:
        return ValidationResult(False, f"DNS resolution failed for '{hostname}'")

    resolved_ips = sorted({info[4][0] for info in addr_infos})
    if not resolved_ips:
        return ValidationResult(False, f"Hostname '{hostname}' did not resolve to any address")

    for ip_str in resolved_ips:
        if _is_blocked_ip(ip_str):
            return ValidationResult(
                False,
                f"Hostname '{hostname}' resolves to non-public address '{ip_str}'",
            )

    return ValidationResult(True, resolved_ips=resolved_ips)
