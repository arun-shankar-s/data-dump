import pytest

from src.services.robots import RobotsChecker


@pytest.mark.asyncio
async def test_robots_example_com():
    checker = RobotsChecker()
    result = await checker.check("https://example.com/")

    assert "allowed" in result
    assert "robots_url" in result
