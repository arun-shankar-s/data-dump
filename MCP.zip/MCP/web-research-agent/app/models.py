from pydantic import BaseModel, Field

class ResearchRequest(BaseModel):
    query: str = Field(min_length=3, max_length=1000)
    max_sources: int = Field(default=5, ge=1, le=8)

class Source(BaseModel):
    title: str = ""
    url: str
    snippet: str = ""
    content: str = ""
    status_code: int | None = None

class ResearchResponse(BaseModel):
    query: str
    answer: str
    sources: list[Source]
    search_results_count: int
    scraped_sources_count: int
