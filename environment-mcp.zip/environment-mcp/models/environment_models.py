from __future__ import annotations

from typing import Any, Literal
from pydantic import BaseModel, Field


class RuntimeVersion(BaseModel):
    installed: bool
    version: str | None = None
    error: str | None = None


class SystemInfo(BaseModel):
    os: str
    os_version: str
    architecture: str
    processor: str
    cpu_count: int | None
    python_version: str
    python_executable: str
    working_directory: str


class ProjectInfo(BaseModel):
    path: str
    exists: bool = True
    project_types: list[str] = Field(default_factory=list)
    frameworks: list[str] = Field(default_factory=list)
    package_managers: list[str] = Field(default_factory=list)
    indicators: list[str] = Field(default_factory=list)
    git_repository: bool = False
    docker: bool = False
    success: bool = True
    error: str | None = None


class PythonPackageInfo(BaseModel):
    name: str
    version: str


class PythonPackagesResponse(BaseModel):
    packages: list[PythonPackageInfo] = Field(default_factory=list)


class NodePackageInfo(BaseModel):
    dependencies: dict[str, str] = Field(default_factory=dict)
    dev_dependencies: dict[str, str] = Field(default_factory=dict)
    success: bool = True
    error: str | None = None


class GitInfo(BaseModel):
    is_repository: bool
    repository_root: str | None = None
    current_branch: str | None = None
    current_commit: str | None = None
    clean: bool | None = None
    modified_files: list[str] = Field(default_factory=list)
    untracked_files: list[str] = Field(default_factory=list)
    staged_files: list[str] = Field(default_factory=list)
    error: str | None = None


class EnvironmentVariableStatus(BaseModel):
    exists: bool
    is_secret: bool


class DiagnosticIssue(BaseModel):
    type: str
    severity: Literal["low", "medium", "high"]
    component: str
    message: str
    recommendation: str


class EnvironmentDiagnosis(BaseModel):
    healthy: bool
    facts: dict[str, Any] = Field(default_factory=dict)
    issues: list[DiagnosticIssue] = Field(default_factory=list)
    success: bool = True
    error: str | None = None


class ErrorResponse(BaseModel):
    success: bool = False
    error: dict[str, str]
