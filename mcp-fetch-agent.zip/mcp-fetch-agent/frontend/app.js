const urlInput = document.getElementById("url-input");
const investigateBtn = document.getElementById("investigate-btn");
const statusItems = Array.from(document.querySelectorAll(".status-item"));
const errorBox = document.getElementById("error-box");
const contentPanel = document.getElementById("content-panel");
const analysisPanel = document.getElementById("analysis-panel");

const STAGES = ["idle", "validating", "starting", "calling", "fetching", "analyzing", "completed"];

function setStage(activeKey, doneKeys = []) {
  statusItems.forEach((el) => {
    const key = el.dataset.key;
    el.classList.remove("active", "done");
    if (doneKeys.includes(key)) {
      el.classList.add("done");
    } else if (key === activeKey) {
      el.classList.add("active");
    }
  });
}

function stagesUpTo(key) {
  const idx = STAGES.indexOf(key);
  return STAGES.slice(0, idx);
}

function showError(message) {
  errorBox.textContent = message;
  errorBox.classList.remove("hidden");
}

function clearError() {
  errorBox.textContent = "";
  errorBox.classList.add("hidden");
}

async function runInvestigation() {
  const url = urlInput.value.trim();
  if (!url) {
    showError("Please enter a URL.");
    return;
  }

  clearError();
  contentPanel.textContent = "";
  analysisPanel.textContent = "";
  investigateBtn.disabled = true;

  try {
    setStage("validating", stagesUpTo("validating"));
    // Brief simulated staging so the trace/status feel responsive;
    // the real work happens in the single POST call below.
    setStage("starting", stagesUpTo("starting"));
    setStage("calling", stagesUpTo("calling"));
    setStage("fetching", stagesUpTo("fetching"));

    const response = await fetch("/api/investigate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url }),
    });

    const data = await response.json().catch(() => null);

    if (!response.ok) {
      const detail = (data && data.detail) || `Request failed with status ${response.status}`;
      throw new Error(detail);
    }

    setStage("analyzing", stagesUpTo("analyzing"));

    contentPanel.textContent = data.content || "(empty content)";

    if (data.llm_configured === false) {
      analysisPanel.textContent = "AI analysis unavailable: no LLM_API_KEY configured on the server.";
    } else {
      analysisPanel.textContent = data.analysis || "(no analysis returned)";
    }

    setStage("completed", stagesUpTo("completed").concat("completed"));
  } catch (err) {
    showError(err.message || "Something went wrong.");
    setStage("idle", []);
  } finally {
    investigateBtn.disabled = false;
  }
}

investigateBtn.addEventListener("click", runInvestigation);
urlInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") runInvestigation();
});
