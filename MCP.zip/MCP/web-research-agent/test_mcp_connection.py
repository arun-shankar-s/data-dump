import asyncio
from app.services.mcp_client import WebFetcherMCPClient

async def main():
    client = WebFetcherMCPClient()
    print("MCP tools:", await client.list_tools())
    print(await client.call_tool(
        "search_web",
        {"query": "Model Context Protocol Python SDK", "max_results": 3},
    ))

if __name__ == "__main__":
    asyncio.run(main())
