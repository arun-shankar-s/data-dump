import React from "react";

export default function App() {
  return (
<div className="page">
{/* NAV */}
<nav className="nav">
<div className="brand">
<div className="brand-name">ARUN SHANKAR</div>
<div className="brand-role">Software Engineer</div>
</div>
<div className="nav-links">
<a href="#">Home</a>
<a href="#">Work</a>
<a href="#">Lab</a>
<a href="#">Notes</a>
<a href="#">About</a>
</div>
<a className="resume-top" href="#">Resume ↗</a>
</nav>
{/* HERO */}
<header className="hero">
<div className="hero-copy">
<div className="eyebrow">SOFTWARE ENGINEER · AI / BACKEND</div>
<h1>
        Building reliable systems<br/>
        with the <span className="orange">power of AI.</span>
</h1>
<p className="hero-description">
        Software Engineer at UST focused on backend systems,
        data pipelines, and AI/LLM applications.
      </p>
<div className="actions">
<a className="btn btn-primary" href="#">View My Work →</a>
<a className="btn" href="#">Resume ↓</a>
</div>
<div className="socials">
<span className="social"><span className="icon">◉</span> GitHub</span>
<span className="social"><span className="icon">in</span> LinkedIn</span>
<span className="social"><span className="icon">✉</span> hello@arunshankar.dev</span>
</div>
</div>
<div aria-label="Portrait placeholder" className="hero-photo"></div>
<aside className="hero-side">
<div className="hero-side-line"></div>
<ul>
<li>Build</li>
<li>Learn</li>
<li>Ship</li>
</ul>
<div className="hand-note">
        Same engineer.<br/>
        Bigger problems.
      </div>
</aside>
</header>
{/* FEATURED WORK */}
<section className="section">
<div className="section-head">
<div className="section-title">
<span className="section-number">01</span>
<span>/</span>
<span>FEATURED WORK</span>
</div>
<span className="section-link">View all projects →</span>
</div>
<div className="work-grid">
<article className="flagship">
<div className="project-copy">
<div className="project-label">FLAGSHIP PROJECT</div>
<h2>RAG Assistant</h2>
<p>
            Document intelligence system for querying
            and understanding large technical documents
            using retrieval augmented generation.
          </p>
<div className="tags">
<span className="tag">Python</span>
<span className="tag">Qdrant</span>
<span className="tag">LLM</span>
<span className="tag">Streamlit</span>
</div>
<a className="case-link" href="#">View Case Study →</a>
</div>
<div className="rag-screen">
<div className="rag-top">CIR 08 · 03 · 10:02</div>
<div className="rag-layout">
<div className="rag-nav">
<div>▣ Home</div>
<div>◉ Ask</div>
<div>◌ Sources</div>
<div>⚙ Settings</div>
</div>
<div className="rag-main">
<h3>Ask your documents</h3>
<p>Upload technical documents and get precise answers.</p>
<div className="rag-input">Ask anything... <span>▌</span></div>
<div className="rag-files">
<div className="rag-file"><span>▣ VECV_Technical_Manual.pdf</span><span>›</span></div>
<div className="rag-file"><span>▣ Engine_Specification.pdf</span><span>›</span></div>
<div className="rag-file"><span>▣ Service_Bulletins.pdf</span><span>›</span></div>
</div>
</div>
</div>
</div>
</article>
<div className="side-projects">
<article className="small-project">
<div>
<h3>Storyboard AI</h3>
<p>AI-powered storyboard generation tool for creative content creation.</p>
<div className="small-tags">
<span className="tag">Python</span>
<span className="tag">Stable Diffusion</span>
</div>
</div>
<div className="small-image storyboard-image"></div>
</article>
<article className="small-project">
<div>
<h3>EmoFlix</h3>
<p>Emotion-aware movie recommendation system using facial expression recognition.</p>
<div className="small-tags">
<span className="tag">Python</span>
<span className="tag">OpenCV</span>
</div>
</div>
<div className="small-image emoflix-image"></div>
</article>
</div>
</div>
</section>
{/* AI ENGINEERING LAB */}
<section className="section lab">
<div className="section-head">
<div className="section-title">
<span className="section-number">02</span>
<span>/</span>
<span>AI ENGINEERING LAB</span>
</div>
<span className="section-link">Explore the lab →</span>
</div>
<div className="lab-grid">
<div className="lab-intro">
<h2>From prompts<br/>to working systems.</h2>
<p>Exploring how to build real software with LLMs, agents, tools and context.</p>
<a className="read-more" href="#">Read More →</a>
</div>
<div className="pipeline">
<div className="pipeline-step">
<div className="step-label">CONTEXT</div>
<div className="step-box">
<span>◉  Codebase</span>
<span>◉  Documents</span>
<span>◉  Web</span>
<span>◉  Data</span>
</div>
</div>
<div className="pipeline-step">
<div className="step-label">ORCHESTRATION</div>
<div className="step-box" className="step-box step-box-center">
<span>Agents</span>
<span>(Serena)</span>
</div>
</div>
<div className="pipeline-step">
<div className="step-label">TOOLS</div>
<div className="step-box">
<span>▣  MCP</span>
<span>▣  Plugins</span>
<span>◇  Custom Tools</span>
</div>
</div>
<div className="pipeline-step">
<div className="step-label">MODELS</div>
<div className="step-box">
<span>◉  Ollama</span>
<span>◉  LiteLLM</span>
<span>◇  OpenRouter</span>
</div>
</div>
<div className="pipeline-step">
<div className="step-label">SYSTEMS</div>
<div className="step-box dark">
<span>Working</span>
<span>Applications</span>
</div>
</div>
<div className="iterate">↖ ───────── Iterate → Improve → Ship ───────── ↗</div>
</div>
</div>
</section>
{/* EXPERIENCE + TECH */}
<div className="two-col">
<section>
<div className="section-title">
<span className="section-number">03</span>
<span>/</span>
<span>EXPERIENCE</span>
</div>
<div className="timeline">
<div className="timeline-item">
<div className="timeline-date">2025 – Present</div>
<div className="timeline-content">
<strong>UST<br/>Software Developer</strong>
<p>
              Building data pipelines, AI applications and
              automation systems. Working with Python, PySpark
              and SQL across data engineering workflows.
            </p>
<div className="tags">
<span className="tag">Python</span>
<span className="tag">PySpark</span>
<span className="tag">SQL</span>
<span className="tag">RAG</span>
</div>
</div>
</div>
<div className="timeline-item">
<div className="timeline-date">2023 – 2025</div>
<div className="timeline-content">
<strong>MCA – Lourdes Matha College of Science and Technology</strong>
<p>7th Rank in MCA batch 2023–25.</p>
</div>
</div>
</div>
</section>
<section>
<div className="section-title">
<span className="section-number">04</span>
<span>/</span>
<span>TECHNICAL FOCUS</span>
</div>
<div className="tech-grid">
<div className="tech-card">
<div className="tech-icon">&lt;/&gt;</div>
<div>
<strong>Backend</strong>
<p>Python, FastAPI, SQL<br/>PostgreSQL, APIs</p>
</div>
</div>
<div className="tech-card">
<div className="tech-icon">♧</div>
<div>
<strong>AI / ML</strong>
<p>RAG, LLMs<br/>Embeddings, PyTorch<br/>HuggingFace</p>
</div>
</div>
<div className="tech-card">
<div className="tech-icon">◉</div>
<div>
<strong>Data Engineering</strong>
<p>PySpark, ETL<br/>Data Pipelines<br/>Databricks, Informatica</p>
</div>
</div>
<div className="tech-card">
<div className="tech-icon">☁</div>
<div>
<strong>Infrastructure</strong>
<p>Docker, AWS<br/>Redis, Git<br/>Linux</p>
</div>
</div>
</div>
</section>
</div>
{/* MOMENTS */}
<section className="section">
<div className="section-head">
<div className="section-title">
<span className="section-number">05</span>
<span>/</span>
<span>MOMENTS</span>
</div>
<span className="section-link">View all photos →</span>
</div>
<div className="moments-grid">
<article className="moment">
<div className="moment-image graduation"></div>
<div className="moment-info">
<strong>Graduation</strong>
<span>MCA 2025</span>
</div>
</article>
<article className="moment">
<div className="moment-image award"></div>
<div className="moment-info">
<strong>7th Rank</strong>
<span>MCA 2023–2025</span>
</div>
</article>
<article className="moment">
<div className="moment-image ust"></div>
<div className="moment-info">
<strong>At UST</strong>
<span>Trivandrum</span>
</div>
</article>
<article className="moment">
<div className="moment-image team"></div>
<div className="moment-info">
<strong>Team &amp; Friends</strong>
<span>Memories</span>
</div>
</article>
</div>
</section>
{/* NOTES */}
<section className="section">
<div className="section-head">
<div className="section-title">
<span className="section-number">06</span>
<span>/</span>
<span>LATEST NOTES</span>
</div>
<span className="section-link">View all notes →</span>
</div>
<div className="notes-grid">
<article className="note">
<div className="note-title">RAG Systems – Key Challenges</div>
<div className="note-date">May 21, 2026</div>
<div className="note-arrow">↗</div>
</article>
<article className="note">
<div className="note-title">Chunking Strategies Compared</div>
<div className="note-date">May 19, 2026</div>
<div className="note-arrow">↗</div>
</article>
<article className="note">
<div className="note-title">Reducing Hallucinations in LLMs</div>
<div className="note-date">May 18, 2026</div>
<div className="note-arrow">↗</div>
</article>
<article className="note">
<div className="note-title">Embedding Models Benchmark</div>
<div className="note-date">May 16, 2026</div>
<div className="note-arrow">↗</div>
</article>
</div>
</section>
{/* CONTACT */}
<section className="section contact">
<div className="section-head">
<div className="section-title">
<span className="section-number">07</span>
<span>/</span>
<span>LET'S BUILD SOMETHING USEFUL</span>
</div>
</div>
<div className="contact-grid">
<h2>Have an engineering problem<br/>or an interesting idea?</h2>
<div className="contact-intro">
        I'm open to opportunities, collaborations
        and projects that make a real impact.
      </div>
<div className="contact-links">
<div className="contact-link">✉ <span>hello@arunshankar.dev</span></div>
<div className="contact-link">in <span>linkedin.com/in/arun-shankar</span></div>
<div className="contact-link">◉ <span>github.com/arunshankar</span></div>
</div>
<div className="contact-note">
        Good<br/>
        systems<br/>
        create<br/>
        better<br/>
        opportunities.
      </div>
</div>
</section>
{/* FOOTER */}
<footer className="footer">
<div>© 2026 Arun Shankar. Built with curiosity.</div>
<div className="footer-links">
<span>Work</span>
<span>Learn</span>
<span>Build</span>
<span>Repeat</span>
<span>↑</span>
</div>
</footer>
</div>
  );
}
