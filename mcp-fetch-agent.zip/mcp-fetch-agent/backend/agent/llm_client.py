"""
Minimal LLM provider abstraction.

Deliberately does not hard-code a specific commercial provider in the
type signature that callers depend on -- `LLMClient.analyze()` is the
only thing the agent needs. The concrete implementation below talks to
an Anthropic-compatible /v1/messages endpoint (configurable via
LLM_BASE_URL so any compatible provider can be swapped in), but that
detail is isolated here.
"""
from __future__ import annotations

import logging

import httpx

from backend.agent.prompts import SYSTEM_PROMPT
from backend.config import settings

logger = logging.getLogger("mcp_fetch_agent.llm_client")

DEFAULT_BASE_URL = "https://api.anthropic.com/v1/messages"


class LLMClient:
    """Abstract interface the agent depends on."""

    async def analyze(self, prompt: str) -> str:
        raise NotImplementedError


class AnthropicLLMClient(LLMClient):
    def __init__(self) -> None:
        self.api_key = settings.LLM_API_KEY
        self.base_url = settings.LLM_BASE_URL or DEFAULT_BASE_URL
        self.model = settings.LLM_MODEL

    async def analyze(self, prompt: str) -> str:
        headers = {
            "content-type": "application/json",
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
        }
        payload = {
            "model": self.model,
            "max_tokens": 500,
            "system": SYSTEM_PROMPT,
            "messages": [{"role": "user", "content": prompt}],
        }
        async with httpx.AsyncClient(timeout=settings.AGENT_TIMEOUT) as client:
            resp = await client.post(self.base_url, headers=headers, json=payload)
            resp.raise_for_status()
            data = resp.json()

        text_blocks = [b["text"] for b in data.get("content", []) if b.get("type") == "text"]
        return "\n".join(text_blocks).strip() or "(model returned no text)"


class NullLLMClient(LLMClient):
    """Used when no LLM_API_KEY is configured."""

    async def analyze(self, prompt: str) -> str:
        return ""


def get_llm_client() -> LLMClient:
    if settings.llm_configured:
        return AnthropicLLMClient()
    logger.info("llm_not_configured_using_null_client")
    return NullLLMClient()
