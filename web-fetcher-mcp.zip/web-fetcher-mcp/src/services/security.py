import ipaddress
import socket
from urllib.parse import urlparse


class URLValidationError(ValueError):
    pass


def _is_private_or_local_ip(ip: str) -> bool:
    address = ipaddress.ip_address(ip)
    return (
        address.is_private
        or address.is_loopback
        or address.is_link_local
        or address.is_reserved
        or address.is_multicast
        or address.is_unspecified
    )


def validate_url(url: str, block_private_networks: bool = True) -> str:
    if not isinstance(url, str) or not url.strip():
        raise URLValidationError("URL cannot be empty.")

    url = url.strip()
    parsed = urlparse(url)

    if parsed.scheme.lower() not in {"http", "https"}:
        raise URLValidationError("Only HTTP and HTTPS URLs are supported.")

    if not parsed.hostname:
        raise URLValidationError("URL must contain a hostname.")

    hostname = parsed.hostname.lower().rstrip(".")

    if hostname in {"localhost", "localhost.localdomain"}:
        raise URLValidationError("Localhost URLs are blocked.")

    if block_private_networks:
        try:
            addresses = socket.getaddrinfo(
                hostname,
                parsed.port or (443 if parsed.scheme == "https" else 80),
                type=socket.SOCK_STREAM,
            )
        except socket.gaierror as exc:
            raise URLValidationError(
                f"Could not resolve hostname: {hostname}"
            ) from exc

        for address in addresses:
            ip = address[4][0]
            if _is_private_or_local_ip(ip):
                raise URLValidationError(
                    "Private or local network targets are blocked."
                )

    return url
