from __future__ import annotations

import logging

from fastapi import APIRouter, HTTPException

from backend.agent.agent import AgentError, InvestigationAgent
from backend.mcp.fetch_client import FetchMcpClient
from backend.models.schemas import (
    HealthResponse,
    InvestigateRequest,
    InvestigateResponse,
    McpStatusResponse,
)
from backend.security.url_validator import validate_url

logger = logging.getLogger("mcp_fetch_agent.routes")

router = APIRouter()


@router.get("/health", response_model=HealthResponse)
async def health() -> HealthResponse:
    return HealthResponse(status="ok")


@router.get("/api/mcp/status", response_model=McpStatusResponse)
async def mcp_status() -> McpStatusResponse:
    try:
        client = FetchMcpClient()
        tools = await client.list_tools()
        return McpStatusResponse(status="ok", tools=tools)
    except Exception as exc:  # noqa: BLE001
        logger.exception("mcp_status_check_failed")
        return McpStatusResponse(status="unavailable", detail=str(exc))


@router.post("/api/investigate", response_model=InvestigateResponse)
async def investigate(payload: InvestigateRequest) -> InvestigateResponse:
    url_str = str(payload.url)
    logger.info("investigation_started url=%s", url_str)

    validation = validate_url(url_str)
    if not validation.is_valid:
        logger.info("url_validation_rejected url=%s reason=%s", url_str, validation.reason)
        raise HTTPException(status_code=400, detail=validation.reason or "URL is not allowed")
    logger.info("url_validation_passed url=%s ips=%s", url_str, validation.resolved_ips)

    agent = InvestigationAgent()
    try:
        result = await agent.investigate(url_str)
    except AgentError as exc:
        logger.warning("investigation_failed url=%s error=%s", url_str, exc)
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except Exception:  # noqa: BLE001
        logger.exception("investigation_unexpected_error url=%s", url_str)
        raise HTTPException(status_code=500, detail="Unexpected server error") from None

    logger.info("investigation_completed url=%s", url_str)

    return InvestigateResponse(
        success=True,
        url=url_str,
        content=result["content"],
        analysis=result["analysis"] or None,
        mcp_tool=result["mcp_tool"],
        llm_configured=result["llm_configured"],
    )
