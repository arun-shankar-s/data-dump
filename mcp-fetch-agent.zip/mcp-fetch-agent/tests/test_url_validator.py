from unittest.mock import patch

import pytest

from backend.security.url_validator import validate_url


def _fake_getaddrinfo(ip):
    """Build a fake socket.getaddrinfo() return value for a given IP."""

    def _fn(hostname, port):
        return [(2, 1, 6, "", (ip, 0))]

    return _fn


@pytest.mark.parametrize(
    "url,expected_ip",
    [
        ("https://example.com", "93.184.216.34"),
        ("http://example.com", "93.184.216.34"),
    ],
)
def test_public_urls_allowed(url, expected_ip):
    with patch("socket.getaddrinfo", side_effect=_fake_getaddrinfo(expected_ip)):
        result = validate_url(url)
    assert result.is_valid is True


@pytest.mark.parametrize(
    "url",
    [
        "http://localhost",
        "http://localhost:8000",
        "http://127.0.0.1",
        "http://0.0.0.0",
        "http://192.168.1.1",
        "http://10.0.0.1",
        "http://172.16.0.1",
        "http://169.254.169.254",
        "ftp://example.com",
        "not-a-url",
        "",
    ],
)
def test_unsafe_or_malformed_urls_rejected(url):
    result = validate_url(url)
    assert result.is_valid is False


def test_dns_rebinding_style_bypass_rejected():
    # A hostname that *looks* public but resolves to a private IP
    # must still be rejected.
    with patch("socket.getaddrinfo", side_effect=_fake_getaddrinfo("10.0.0.5")):
        result = validate_url("http://looks-public.example.com")
    assert result.is_valid is False


def test_dns_failure_rejected():
    import socket

    with patch("socket.getaddrinfo", side_effect=socket.gaierror("no such host")):
        result = validate_url("http://this-domain-does-not-exist.invalid")
    assert result.is_valid is False
