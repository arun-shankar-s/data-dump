# MCP Fetch Agent

A minimal application demonstrating:

```
Application
    ↓
MCP Client
    ↓
Fetch MCP Server
    ↓
Web
```

You enter a public URL in the browser. A FastAPI backend validates it,
hands it to an agent, and the agent retrieves the page **through the
official `mcp-server-fetch` MCP server** — not with `requests` or
`httpx` directly. The retrieved content is then (optionally) summarized
by an LLM, and both the raw content and the analysis are shown in the
UI, along with a trace of the MCP flow.

## Why MCP?

The Model Context Protocol provides an abstraction between the
application/agent and the actual tool implementation. This app knows
only the *contract* `fetch(url) -> text`, exposed by the Fetch MCP
server. It does not implement webpage retrieval itself. That boundary
— frontend → FastAPI → Agent → **MCP Client** → Fetch MCP Server → Web
— is the entire point of this project. Swapping in a different fetch
implementation, or adding more MCP tools/servers later, would not
require changing the agent's public interface.

## Architecture

```
Browser (HTML/CSS/JS)
        │  POST /api/investigate
        ▼
FastAPI Backend
   API layer → Agent → MCP Client
        │  MCP / stdio
        ▼
Fetch MCP Server (mcp-server-fetch)
   tool: fetch
        │
        ▼
      Web
```

## Project structure

```
mcp-fetch-agent/
├── backend/
│   ├── main.py            FastAPI app + static frontend mount
│   ├── config.py          env-based settings
│   ├── api/routes.py      /api/investigate, /health, /api/mcp/status
│   ├── agent/
│   │   ├── agent.py       orchestrates MCP fetch + LLM analysis
│   │   ├── llm_client.py  provider-agnostic LLM abstraction
│   │   └── prompts.py     system + analysis prompts
│   ├── mcp/fetch_client.py   the only code that talks to mcp-server-fetch
│   ├── security/url_validator.py  SSRF-safe URL validation
│   └── models/schemas.py  Pydantic request/response models
├── frontend/               HTML + CSS + vanilla JS, no frameworks
├── tests/
├── requirements.txt
├── .env.example
└── run.py
```

## URL security (SSRF protection)

`backend/security/url_validator.py` is deliberately conservative and
**fails closed**:

- Only `http`/`https` schemes are allowed.
- `localhost`, `127.0.0.1`, `0.0.0.0`, and hostnames containing
  `.local`/`.internal`/`.corp`/`.lan`/`.home` are rejected outright.
- If the host is a literal IP, it's checked directly against
  loopback/private/link-local/reserved/multicast/unspecified ranges.
- If the host is a domain name, it is **resolved via DNS first**, and
  every returned address is checked the same way. This blocks
  "DNS rebinding" SSRF bypasses where a public-looking hostname
  resolves to an internal IP (e.g. `169.254.169.254`, the common cloud
  metadata address).
- Any DNS failure, malformed URL, or unrecognized address shape is
  rejected rather than allowed — the validator only ever says yes to
  addresses it can positively classify as public.

This protects the Fetch MCP server (which will retrieve whatever URL
it's given) from being used to reach internal services.

## MCP lifecycle

For this MVP, a fresh `mcp-server-fetch` process and MCP session is
created **per investigation**: start server → initialize session →
discover tools → call `fetch` → close session. `FetchMcpClient` holds
no global state, so this can later become a persistent/pooled session
without changing its callers.

## LLM analysis (optional)

`backend/agent/llm_client.py` defines a small `LLMClient.analyze()`
interface. If `LLM_API_KEY` is not set, the app still fetches and
displays the page content via MCP — it just shows "AI analysis
unavailable" instead of fabricating a summary.

## Installation (Windows)

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

You'll also need [`uv`](https://docs.astral.sh/uv/) installed and on
your PATH, since the Fetch MCP server is launched via `uvx
mcp-server-fetch` rather than being vendored into this repo.

Copy `.env.example` to `.env` and fill in `LLM_API_KEY` if you want AI
analysis (optional).

## Running

```powershell
uvicorn backend.main:app --reload --port 8000
```

Then open **http://localhost:8000** — FastAPI serves the frontend
directly, so no separate frontend server or Node.js is needed.

Health check: `GET http://localhost:8000/health`
MCP diagnostics: `GET http://localhost:8000/api/mcp/status`

## Tests

```powershell
pytest
```

`tests/test_url_validator.py` covers allowed/blocked URLs (including
the DNS-rebinding case) with `socket.getaddrinfo` mocked so tests don't
require network access. `tests/test_fetch_client.py` mocks the MCP
transport/session to verify tool discovery, successful fetch, missing
"fetch" tool, tool-reported errors, and transport failures — without
needing `uv`/`mcp-server-fetch` installed or internet access.

## What this deliberately does NOT do

- No `requests.get()`/`httpx.get()` for fetching the target page —
  only the Fetch MCP tool does that.
- No VS Code MCP configuration required; the backend is its own MCP
  client and runs standalone.
- No React/Vue/Angular/Node.js frontend.
