from services.project_service import get_project_info

def test_project_detection(tmp_path):
    (tmp_path / "pyproject.toml").write_text('[project]\nname="demo"\ndependencies=["fastapi>=0.1"]\n')
    (tmp_path / "package.json").write_text('{"dependencies":{"react":"^19.0.0"}}')
    (tmp_path / "Dockerfile").write_text("FROM python:3.12\n")
    info = get_project_info(str(tmp_path))
    assert "python" in info.project_types
    assert "javascript" in info.project_types
    assert "FastAPI" in info.frameworks
    assert "React" in info.frameworks
    assert info.docker is True
