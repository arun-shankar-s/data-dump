from services.diagnostic_service import diagnose_environment
from config import is_secret_name


def register(mcp):
    @mcp.tool()
    def diagnose_environment(path: str | None = None):
        """Combine environment facts with deterministic development-environment diagnostics."""
        return diagnose_environment(path)

    @mcp.tool()
    def check_environment_variables(names: list[str]):
        """Report whether named environment variables exist without ever returning their values."""
        import os
        return {
            name: {
                "exists": name in os.environ,
                "is_secret": is_secret_name(name),
            }
            for name in names
        }
