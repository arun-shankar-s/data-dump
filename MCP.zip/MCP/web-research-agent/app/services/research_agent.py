import asyncio
from urllib.parse import urlparse

from openai import AsyncOpenAI

from app.config import settings
from app.models import ResearchResponse, Source
from app.services.mcp_client import WebFetcherMCPClient


llm_client = AsyncOpenAI(
    api_key=settings.openai_api_key,
    base_url=settings.openai_base_url,
)


class ResearchAgent:

    def __init__(self):
        self.mcp = WebFetcherMCPClient()

    async def research(
        self,
        query: str,
        max_sources: int,
    ) -> ResearchResponse:

        # ---------------------------------------------------------
        # 1. Search the web through MCP
        # ---------------------------------------------------------

        search = await self.mcp.call_tool(
            "search_web",
            {
                "query": query,
                "max_results": min(
                    max_sources + 3,
                    settings.max_search_results,
                ),
            },
        )

        results = (
            search.get("results", [])
            if isinstance(search, dict)
            else []
        )

        # ---------------------------------------------------------
        # 2. Select diverse sources
        # ---------------------------------------------------------

        selected = []
        domains = set()

        for item in results:

            url = item.get("url", "")

            if not url:
                continue

            try:
                domain = urlparse(url).netloc.lower()
            except Exception:
                continue

            # Avoid multiple pages from the same domain
            if domain in domains:
                continue

            domains.add(domain)
            selected.append(item)

            if len(selected) >= max_sources:
                break

        # ---------------------------------------------------------
        # 3. Scrape selected sources through MCP
        # ---------------------------------------------------------

        scraped = await asyncio.gather(
            *[
                self._scrape(item)
                for item in selected
            ],
            return_exceptions=True,
        )

        sources = [
            item
            for item in scraped
            if isinstance(item, Source)
        ]

        # ---------------------------------------------------------
        # 4. Send collected evidence to LLM
        # ---------------------------------------------------------

        answer = await self._synthesize(
            query,
            sources,
        )

        # ---------------------------------------------------------
        # 5. Return research response
        # ---------------------------------------------------------

        return ResearchResponse(
            query=query,
            answer=answer,
            sources=sources,
            search_results_count=len(results),
            scraped_sources_count=len(sources),
        )

    async def _scrape(
        self,
        item: dict,
    ) -> Source | None:

        url = item.get("url", "")

        if not url:
            return None

        try:

            data = await self.mcp.call_tool(
                "scrape_page",
                {
                    "url": url,
                },
            )

            if not isinstance(data, dict):
                return None

            if data.get("error"):
                return None

            content = data.get(
                "content",
                "",
            )

            content = content[
                :settings.max_source_chars
            ]

            return Source(
                title=(
                    data.get("title")
                    or item.get("title", "")
                ),
                url=data.get(
                    "url",
                    url,
                ),
                snippet=item.get(
                    "snippet",
                    "",
                ),
                content=content,
                status_code=data.get(
                    "status_code"
                ),
            )

        except Exception as exc:

            print(
                f"Failed to scrape {url}: {exc}"
            )

            return None

    async def _synthesize(
        self,
        query: str,
        sources: list[Source],
    ) -> str:

        if not sources:
            return (
                "No usable web sources "
                "were retrieved."
            )

        # ---------------------------------------------------------
        # Build research evidence
        # ---------------------------------------------------------

        evidence = "\n\n".join(
            (
                f"SOURCE {index}\n"
                f"Title: {source.title}\n"
                f"URL: {source.url}\n"
                f"Content:\n{source.content}"
            )
            for index, source in enumerate(
                sources,
                start=1,
            )
        )

        evidence = evidence[
            :settings.max_total_research_chars
        ]

        # ---------------------------------------------------------
        # LLM prompt
        # ---------------------------------------------------------

        prompt = f"""
You are a careful web research analyst.

Answer the user's question using ONLY the supplied
source material.

Question:
{query}

Requirements:

- Give the direct answer first.
- Cite claims inline using [1], [2], etc.
- Do not invent facts that are not supported by
  the supplied sources.
- If sources disagree, explicitly mention it.
- Distinguish facts from inference.
- Prefer concise, useful explanations.
- End with a short "Sources used" section.

SOURCE MATERIAL:

{evidence}
""".strip()

        # ---------------------------------------------------------
        # OpenAI-compatible API
        # ---------------------------------------------------------

        response = await llm_client.chat.completions.create(
            model=settings.openai_model,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are a careful web research "
                        "assistant. Ground your answer "
                        "strictly in the supplied evidence."
                    ),
                },
                {
                    "role": "user",
                    "content": prompt,
                },
            ],
            temperature=0.2,
        )

        # ---------------------------------------------------------
        # Extract response
        # ---------------------------------------------------------

        answer = (
            response.choices[0]
            .message
            .content
        )

        if not answer:
            return "The LLM returned an empty response."

        return answer