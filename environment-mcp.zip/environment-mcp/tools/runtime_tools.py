from services.runtime_service import get_runtime_versions


def register(mcp):
    @mcp.tool()
    def get_runtime_versions():
        """Detect installed versions of Python, Node.js, npm, Java, Git, and Docker."""
        return get_runtime_versions()
