import os
from dataclasses import dataclass


def _int_env(name: str, default: int) -> int:
    value = os.getenv(name)
    if value is None:
        return default
    try:
        return int(value)
    except ValueError:
        return default


def _float_env(name: str, default: float) -> float:
    value = os.getenv(name)
    if value is None:
        return default
    try:
        return float(value)
    except ValueError:
        return default


def _bool_env(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    user_agent: str = os.getenv("WEB_FETCHER_USER_AGENT", "WebFetcherMCP/1.0")
    timeout: float = _float_env("WEB_FETCHER_TIMEOUT", 20.0)
    max_content_bytes: int = _int_env(
        "WEB_FETCHER_MAX_CONTENT_BYTES", 2 * 1024 * 1024
    )
    max_links: int = _int_env("WEB_FETCHER_MAX_LINKS", 500)
    max_concurrent: int = _int_env("WEB_FETCHER_MAX_CONCURRENT", 5)
    block_private_networks: bool = _bool_env(
        "WEB_FETCHER_BLOCK_PRIVATE_NETWORKS", True
    )


settings = Settings()
