from __future__ import annotations

import re
import shutil
import subprocess
from models.environment_models import RuntimeVersion
from config import SAFE_COMMANDS


def _extract_version(output: str) -> str | None:
    match = re.search(r"\d+(?:\.\d+)+(?:[-+][0-9A-Za-z.-]+)?", output)
    return match.group(0) if match else None


def _run_version(name: str) -> RuntimeVersion:
    command = SAFE_COMMANDS[name]
    executable = shutil.which(command[0])
    if executable is None:
        return RuntimeVersion(installed=False, version=None)

    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
            shell=False,
        )
        output = (completed.stdout or "") + "\n" + (completed.stderr or "")
        version = _extract_version(output)
        if completed.returncode != 0 and not version:
            return RuntimeVersion(installed=True, version=None, error="Unable to parse version")
        return RuntimeVersion(installed=True, version=version)
    except (OSError, subprocess.SubprocessError) as exc:
        return RuntimeVersion(installed=False, version=None, error=str(exc))


def get_runtime_versions() -> dict[str, RuntimeVersion]:
    return {name: _run_version(name) for name in SAFE_COMMANDS}
