from ddgs import DDGS


class WebSearch:
    def search(self, query: str, max_results: int = 10) -> list[dict]:
        results = []

        with DDGS() as ddgs:
            search_results = ddgs.text(
                query,
                max_results=max_results,
            )

            for result in search_results:
                results.append({
                    "title": result.get("title", ""),
                    "url": result.get(
                        "href",
                        result.get("url", ""),
                    ),
                    "snippet": result.get(
                        "body",
                        result.get("snippet", ""),
                    ),
                })

        return results
