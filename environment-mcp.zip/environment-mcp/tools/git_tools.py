from services.git_service import get_git_info


def register(mcp):
    @mcp.tool()
    def get_git_info(path: str | None = None):
        """Inspect Git repository state using a fixed safe command allowlist."""
        return get_git_info(path)
