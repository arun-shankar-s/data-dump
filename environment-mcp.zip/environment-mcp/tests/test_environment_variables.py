from tools.diagnostic_tools import register
from config import is_secret_name

def test_secret_detection():
    assert is_secret_name("OPENAI_API_KEY") is True
    assert is_secret_name("DATABASE_URL") is False
    assert is_secret_name("PASSWORD") is True
