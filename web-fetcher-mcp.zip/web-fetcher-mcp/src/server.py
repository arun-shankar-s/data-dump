import asyncio

from mcp.server.fastmcp import FastMCP

from src.config import settings
from src.services.fetcher import WebFetcher
from src.services.parser import WebParser
from src.services.robots import RobotsChecker
from src.services.search import WebSearch


mcp = FastMCP("Web Fetcher")

fetcher = WebFetcher()
parser = WebParser()
robots = RobotsChecker()
search = WebSearch()


def error_response(url: str, exc: Exception) -> dict:
    return {
        "url": url,
        "error": type(exc).__name__,
        "message": str(exc),
    }


@mcp.tool()
async def search_web(query: str, max_results: int = 10) -> dict:
    """Search the web and return titles, URLs, and snippets."""
    if not query or not query.strip():
        return {"error": "Search query cannot be empty."}

    max_results = max(1, min(max_results, 20))

    try:
        results = await asyncio.to_thread(
            search.search,
            query.strip(),
            max_results,
        )
        return {
            "query": query.strip(),
            "count": len(results),
            "results": results,
        }
    except Exception as exc:
        return {
            "query": query.strip(),
            "error": type(exc).__name__,
            "message": str(exc),
        }


@mcp.tool()
async def check_robots_txt(url: str) -> dict:
    """Check whether a URL is allowed by robots.txt."""
    try:
        return await robots.check(url)
    except Exception as exc:
        return error_response(url, exc)


@mcp.tool()
async def fetch_url(url: str) -> dict:
    """Fetch a webpage while respecting robots.txt."""
    try:
        result = await fetcher.fetch(url, respect_robots=True)
        return {
            "url": result.url,
            "status_code": result.status_code,
            "content_type": result.content_type,
            "content_length": result.content_length,
            "truncated": result.truncated,
            "content": result.content,
        }
    except Exception as exc:
        return error_response(url, exc)


@mcp.tool()
async def scrape_page(url: str) -> dict:
    """Fetch a webpage and extract readable content and metadata."""
    try:
        result = await fetcher.fetch(url, respect_robots=True)
        metadata = parser.metadata(result.content)
        text = parser.clean_text(result.content)

        return {
            "url": result.url,
            "status_code": result.status_code,
            "content_type": result.content_type,
            "content_length": result.content_length,
            "truncated": result.truncated,
            "title": metadata["title"],
            "description": metadata["description"],
            "headings": metadata["headings"],
            "content": text,
        }
    except Exception as exc:
        return error_response(url, exc)


@mcp.tool()
async def extract_links(url: str) -> dict:
    """Fetch a webpage and extract absolute links."""
    try:
        result = await fetcher.fetch(url, respect_robots=True)
        links = parser.extract_links(
            result.content,
            result.url,
            max_links=settings.max_links,
        )
        return {
            "url": result.url,
            "count": len(links),
            "links": links,
        }
    except Exception as exc:
        return error_response(url, exc)


@mcp.tool()
async def fetch_multiple(urls: list[str]) -> dict:
    """Fetch multiple webpages concurrently with robots.txt checks."""
    if not urls:
        return {"count": 0, "results": []}

    semaphore = asyncio.Semaphore(settings.max_concurrent)

    async def fetch_one(url: str):
        async with semaphore:
            try:
                result = await fetcher.fetch(
                    url,
                    respect_robots=True,
                )
                return {
                    "url": result.url,
                    "status_code": result.status_code,
                    "content_type": result.content_type,
                    "content_length": result.content_length,
                    "truncated": result.truncated,
                    "content": result.content,
                }
            except Exception as exc:
                return error_response(url, exc)

    results = await asyncio.gather(
        *(fetch_one(url) for url in urls)
    )

    return {
        "count": len(results),
        "results": results,
    }


if __name__ == "__main__":
    mcp.run()
