import pytest

from src.services.security import URLValidationError, validate_url


def test_http_url_is_valid():
    assert validate_url(
        "https://example.com",
        block_private_networks=False,
    ) == "https://example.com"


def test_unsupported_scheme_is_rejected():
    with pytest.raises(URLValidationError):
        validate_url("file:///etc/passwd")


def test_localhost_is_rejected():
    with pytest.raises(URLValidationError):
        validate_url("http://localhost:8000")
