from __future__ import annotations

import json
import tomllib
from pathlib import Path

from config import NODE_FRAMEWORKS, PYTHON_FRAMEWORKS, resolve_project_path
from models.environment_models import ProjectInfo


def _read_text(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


def _python_dependencies(path: Path) -> set[str]:
    deps: set[str] = set()
    req = path / "requirements.txt"
    if req.exists():
        for line in _read_text(req).splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            name = line.split("[", 1)[0]
            for op in (">=", "<=", "==", ">", "<", "~=", "!="):
                name = name.split(op, 1)[0]
            deps.add(name.strip().lower())

    pyproject = path / "pyproject.toml"
    if pyproject.exists():
        try:
            data = tomllib.loads(_read_text(pyproject))
            project = data.get("project", {})
            for dep in project.get("dependencies", []):
                name = dep.split("[", 1)[0]
                for op in (">=", "<=", "==", ">", "<", "~=", "!="):
                    name = name.split(op, 1)[0]
                deps.add(name.strip().lower())
        except (tomllib.TOMLDecodeError, TypeError, ValueError):
            pass
    return deps


def _node_dependencies(path: Path) -> set[str]:
    package = path / "package.json"
    if not package.exists():
        return set()
    try:
        data = json.loads(_read_text(package))
        return {
            str(name).lower()
            for name in {
                **data.get("dependencies", {}),
                **data.get("devDependencies", {}),
            }
        }
    except (json.JSONDecodeError, TypeError, ValueError):
        return set()


def get_project_info(path: str | None = None) -> ProjectInfo:
    project_path = resolve_project_path(path)
    if not project_path.exists():
        return ProjectInfo(
            path=str(project_path),
            exists=False,
            success=False,
            error="Project path does not exist.",
        )
    if not project_path.is_dir():
        return ProjectInfo(
            path=str(project_path),
            success=False,
            error="Project path is not a directory.",
        )

    indicators = [
        name for name in (
            "pyproject.toml", "requirements.txt", "setup.py", "Pipfile",
            "package.json", "package-lock.json", "pom.xml", "build.gradle",
            "build.gradle.kts", "go.mod", "Cargo.toml", "Dockerfile",
            "docker-compose.yml", "docker-compose.yaml",
        ) if (project_path / name).exists()
    ]
    indicators.extend(p.name for p in project_path.glob("*.csproj") if p.is_file())

    types: list[str] = []
    managers: list[str] = []
    if any(x in indicators for x in ("pyproject.toml", "requirements.txt", "setup.py", "Pipfile")):
        types.append("python")
    if "package.json" in indicators:
        types.append("javascript")
    if any(x in indicators for x in ("pom.xml", "build.gradle", "build.gradle.kts")):
        types.append("java")
    if "go.mod" in indicators:
        types.append("go")
    if "Cargo.toml" in indicators:
        types.append("rust")
    if any(x.endswith(".csproj") for x in indicators):
        types.append("csharp")

    if "requirements.txt" in indicators or "pyproject.toml" in indicators or "setup.py" in indicators:
        managers.append("pip")
    if "Pipfile" in indicators:
        managers.append("pipenv")
    if "package.json" in indicators:
        managers.append("npm")
    if "package-lock.json" in indicators:
        managers.append("npm")
    if "pom.xml" in indicators:
        managers.append("maven")
    if "build.gradle" in indicators or "build.gradle.kts" in indicators:
        managers.append("gradle")
    if "go.mod" in indicators:
        managers.append("go")
    if "Cargo.toml" in indicators:
        managers.append("cargo")

    python_deps = _python_dependencies(project_path)
    node_deps = _node_dependencies(project_path)
    frameworks = [name for dep, name in PYTHON_FRAMEWORKS.items() if dep in python_deps]
    frameworks += [name for dep, name in NODE_FRAMEWORKS.items() if dep in node_deps]

    git_repository = (project_path / ".git").exists()
    docker = any(x in indicators for x in ("Dockerfile", "docker-compose.yml", "docker-compose.yaml"))

    return ProjectInfo(
        path=str(project_path),
        project_types=sorted(set(types)),
        frameworks=sorted(set(frameworks)),
        package_managers=sorted(set(managers)),
        indicators=sorted(indicators),
        git_repository=git_repository,
        docker=docker,
    )
