from services.runtime_service import _extract_version

def test_extract_version():
    assert _extract_version("Python 3.12.6") == "3.12.6"
    assert _extract_version("v22.14.0") == "22.14.0"
    assert _extract_version("no version") is None
