# Web Research Agent

FastAPI application using the Web Fetcher MCP through a real MCP stdio client.

Flow:

Browser -> FastAPI -> Research Agent -> MCP Client -> Web Fetcher MCP -> Web
Research Agent -> Ollama -> grounded answer

Setup:

1. Put this folder beside `web-fetcher-mcp`.
2. Create a venv and install `requirements.txt`.
3. Copy `.env.example` to `.env`.
4. Set the absolute `MCP_SERVER_PATH`.
5. Make sure Ollama is running and `OLLAMA_MODEL` exists.
6. Run `uvicorn app.main:app --reload --port 8002`.
7. Open http://127.0.0.1:8002

The agent calls `search_web`, selects diverse sources, calls `scrape_page`, then sends the collected evidence to Ollama.
