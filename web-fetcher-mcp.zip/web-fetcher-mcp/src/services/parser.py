from urllib.parse import urljoin

from bs4 import BeautifulSoup


class WebParser:
    @staticmethod
    def clean_text(html: str) -> str:
        soup = BeautifulSoup(html, "lxml")

        for element in soup(
            ["script", "style", "noscript", "svg",
             "nav", "footer", "header", "form", "aside"]
        ):
            element.decompose()

        text = soup.get_text(separator="\n")
        lines = []
        previous_blank = False

        for raw_line in text.splitlines():
            line = " ".join(raw_line.split())

            if not line:
                if not previous_blank:
                    lines.append("")
                previous_blank = True
                continue

            lines.append(line)
            previous_blank = False

        return "\n".join(lines).strip()

    @staticmethod
    def extract_links(html: str, base_url: str, max_links: int = 500) -> list[dict]:
        soup = BeautifulSoup(html, "lxml")
        links = []
        seen = set()

        for anchor in soup.find_all("a", href=True):
            href = anchor.get("href")
            if not href:
                continue

            absolute_url = urljoin(base_url, href)
            if absolute_url in seen:
                continue

            seen.add(absolute_url)
            links.append({
                "text": anchor.get_text(" ", strip=True),
                "url": absolute_url,
            })

            if len(links) >= max_links:
                break

        return links

    @staticmethod
    def metadata(html: str) -> dict:
        soup = BeautifulSoup(html, "lxml")

        title = soup.title.get_text(strip=True) if soup.title else ""

        description = ""
        description_tag = soup.find(
            "meta",
            attrs={"name": "description"},
        )
        if description_tag:
            description = (
                description_tag.get("content", "") or ""
            ).strip()

        headings = []
        for heading in soup.find_all(["h1", "h2", "h3"]):
            text = heading.get_text(" ", strip=True)
            if text:
                headings.append({
                    "level": heading.name,
                    "text": text,
                })

        return {
            "title": title,
            "description": description,
            "headings": headings,
        }
