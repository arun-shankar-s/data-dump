from services.system_service import get_system_info


def register(mcp):
    @mcp.tool()
    def get_system_info():
        """Return read-only information about the current operating system and Python process."""
        return get_system_info()
