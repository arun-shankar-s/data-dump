# Environment MCP

A reusable, read-only MCP server that exposes structured information about a developer's local environment to AI coding assistants.

## Features

- System inspection
- Runtime detection
- Project detection
- Python package inspection
- Node package inspection
- Git inspection
- Environment-variable presence checks without values
- Deterministic environment diagnostics

## Architecture

```text
AI Coding Assistant
        |
        | MCP
        v
Environment MCP
        |
  +-----+-----+-------+
  |     |     |       |
System Project Git Packages
        |
        v
   Diagnostics
```

## Installation

Python 3.11+ is required.

```powershell
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## Run

```powershell
python server.py
```

For an MCP client using stdio, configure it to launch `python server.py` from this project directory.

## MCP Inspector

Install/run MCP Inspector using the version recommended by the official MCP documentation, then connect it to:

```text
python server.py
```

Verify discovery and invocation of:

- `get_system_info`
- `get_runtime_versions`
- `get_project_info`
- `get_python_packages`
- `get_node_packages`
- `get_git_info`
- `diagnose_environment`
- `check_environment_variables`

## Security

V1 is strictly read-only. It does not expose arbitrary command execution, package installation, file modification, Git modification, or environment-variable values.

Subprocess usage is limited to predefined version and Git inspection commands.

## Tests

```powershell
pytest -q
```

The tests use temporary project directories and do not require Docker, Node.js, Java, or other optional runtimes to be installed.
