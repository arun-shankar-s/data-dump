from services.package_service import get_node_packages, get_python_packages


def register(mcp):
    @mcp.tool()
    def get_python_packages(search: str | None = None):
        """List installed Python packages, optionally filtered by package name."""
        return get_python_packages(search)

    @mcp.tool()
    def get_node_packages(path: str | None = None):
        """Read dependencies and devDependencies from package.json without running npm."""
        return get_node_packages(path)
