import os
import platform
import sys
from models.environment_models import SystemInfo


def get_system_info() -> SystemInfo:
    return SystemInfo(
        os=platform.system(),
        os_version=platform.version(),
        architecture=platform.machine(),
        processor=platform.processor() or "unknown",
        cpu_count=os.cpu_count(),
        python_version=platform.python_version(),
        python_executable=sys.executable,
        working_directory=os.getcwd(),
    )
