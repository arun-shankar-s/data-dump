"""
MCP client for the official "mcp-server-fetch" server.

This is the ONLY place in the codebase that is allowed to talk to the
Fetch MCP server. It owns the full MCP lifecycle for a single
investigation: start the server over stdio, initialize a session,
discover tools, call "fetch", and shut the session down again.

Deliberately does NOT use requests/httpx to retrieve the target page --
that would defeat the purpose of demonstrating the MCP abstraction.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

from backend.config import settings

logger = logging.getLogger("mcp_fetch_agent.mcp_client")


class McpToolNotFoundError(Exception):
    pass


class McpFetchError(Exception):
    pass


@dataclass
class FetchResult:
    content: str
    tool_name: str = "fetch"


class FetchMcpClient:
    """
    Thin wrapper around an MCP session with the Fetch server.

    For this MVP a fresh server process + session is created per
    investigation (see backend/mcp/fetch_client.py docstring / README
    "MCP Lifecycle" section for the tradeoff). The class holds no
    global state, so swapping this for a persistent/pooled session
    later does not require changes to callers.
    """

    def __init__(self) -> None:
        self._server_params = StdioServerParameters(
            command=settings.MCP_FETCH_COMMAND,
            args=settings.MCP_FETCH_ARGS,
        )

    async def list_tools(self) -> list[str]:
        """Start the server, initialize a session, and return tool names."""
        async with stdio_client(self._server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                tools = await session.list_tools()
                return [t.name for t in tools.tools]

    async def fetch(self, url: str, timeout: int | None = None) -> FetchResult:
        """
        Run the full MCP lifecycle for a single fetch of `url`:
        start server -> init session -> discover tools -> verify
        "fetch" exists -> call it -> extract text -> close session.
        """
        timeout = timeout or settings.FETCH_TIMEOUT
        logger.info("mcp_server_starting")

        try:
            async with stdio_client(self._server_params) as (read, write):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    logger.info("mcp_session_initialized")

                    tools_result = await session.list_tools()
                    tool_names = [t.name for t in tools_result.tools]
                    logger.info("mcp_tools_discovered tools=%s", tool_names)

                    if "fetch" not in tool_names:
                        raise McpToolNotFoundError(
                            f"'fetch' tool not found on MCP server; available tools: {tool_names}"
                        )

                    logger.info("mcp_fetch_tool_calling url=%s", url)
                    call_result = await session.call_tool("fetch", {"url": url})
                    logger.info("mcp_fetch_tool_returned")

                    if getattr(call_result, "isError", False):
                        raise McpFetchError(f"Fetch MCP tool reported an error for url={url}")

                    text_parts = [
                        block.text
                        for block in call_result.content
                        if getattr(block, "type", None) == "text"
                    ]

                    if not text_parts:
                        raise McpFetchError("Fetch MCP tool returned no text content")

                    return FetchResult(content="\n".join(text_parts))

        except (McpToolNotFoundError, McpFetchError):
            raise
        except Exception as exc:  # noqa: BLE001 - convert any MCP/transport failure
            logger.exception("mcp_fetch_unexpected_error")
            raise McpFetchError(f"MCP fetch failed: {exc}") from exc
