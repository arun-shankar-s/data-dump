import asyncio

from src.services.fetcher import WebFetcher
from src.services.parser import WebParser
from src.services.robots import RobotsChecker


async def main():
    url = "https://example.com/"

    checker = RobotsChecker()
    print("ROBOTS")
    print(await checker.check(url))

    fetcher = WebFetcher()
    result = await fetcher.fetch(url)

    print("\nFETCH")
    print("status:", result.status_code)
    print("content type:", result.content_type)

    parser = WebParser()
    print("\nMETADATA")
    print(parser.metadata(result.content))

    print("\nTEXT")
    print(parser.clean_text(result.content))


if __name__ == "__main__":
    asyncio.run(main())
