from __future__ import annotations

import re
from pathlib import Path

from models.environment_models import DiagnosticIssue, EnvironmentDiagnosis
from services.git_service import get_git_info
from services.node_version import node_version_available
from services.package_service import get_node_packages, get_python_packages
from services.project_service import get_project_info
from services.runtime_service import get_runtime_versions
from services.system_service import get_system_info


def _parse_version(value: str | None) -> tuple[int, ...] | None:
    if not value:
        return None
    match = re.search(r"\d+(?:\.\d+)+", value)
    return tuple(int(x) for x in match.group(0).split(".")) if match else None


def _python_requirement(project_path: Path) -> str | None:
    pyproject = project_path / "pyproject.toml"
    if not pyproject.exists():
        return None
    try:
        import tomllib
        data = tomllib.loads(pyproject.read_text(encoding="utf-8", errors="replace"))
        return data.get("project", {}).get("requires-python")
    except Exception:
        return None


def _python_matches(requirement: str, current: tuple[int, ...]) -> bool:
    # V1 intentionally supports common exact/range expressions rather than a full PEP 508 solver.
    checks = re.findall(r"(>=|<=|==|>|<|~=)\s*(\d+(?:\.\d+)*)", requirement)
    if not checks:
        return True
    for op, raw in checks:
        wanted = tuple(int(x) for x in raw.split("."))
        lhs = current[: len(wanted)]
        if op == ">=" and lhs < wanted:
            return False
        if op == "<=" and lhs > wanted:
            return False
        if op == ">" and lhs <= wanted:
            return False
        if op == "<" and lhs >= wanted:
            return False
        if op == "==" and lhs != wanted:
            return False
        if op == "~=" and lhs[:1] != wanted[:1]:
            return False
    return True


def diagnose_environment(path: str | None = None) -> EnvironmentDiagnosis:
    project = get_project_info(path)
    if not project.success:
        return EnvironmentDiagnosis(
            healthy=False,
            facts={"project": project.model_dump()},
            issues=[DiagnosticIssue(
                type="invalid_project_path",
                severity="high",
                component="filesystem",
                message=project.error or "Invalid project path.",
                recommendation="Provide an existing project directory.",
            )],
            success=False,
            error=project.error,
        )

    runtimes = get_runtime_versions()
    git = get_git_info(path)
    project_path = Path(project.path)
    issues: list[DiagnosticIssue] = []

    if "python" in project.project_types:
        requirement = _python_requirement(project_path)
        current = _parse_version(runtimes["python"].version)
        if requirement and current and not _python_matches(requirement, current):
            issues.append(DiagnosticIssue(
                type="runtime_mismatch",
                severity="high",
                component="python",
                message=f"Project requires Python {requirement}; current Python is {runtimes['python'].version}.",
                recommendation="Use a Python interpreter compatible with the project's requires-python constraint.",
            ))
        if not any((project_path / name).exists() for name in ("requirements.txt", "pyproject.toml", "setup.py", "Pipfile")):
            issues.append(DiagnosticIssue(
                type="missing_dependency_files",
                severity="medium",
                component="python",
                message="Python project detected but no dependency/configuration file was found.",
                recommendation="Add pyproject.toml, requirements.txt, setup.py, or Pipfile as appropriate.",
            ))

    if "javascript" in project.project_types and not runtimes["node"].installed:
        issues.append(DiagnosticIssue(
            type="missing_runtime",
            severity="high",
            component="node",
            message="package.json exists but Node.js is unavailable.",
            recommendation="Install Node.js or make the intended Node.js runtime available on PATH.",
        ))

    if project.docker and not runtimes["docker"].installed:
        issues.append(DiagnosticIssue(
            type="missing_runtime",
            severity="medium",
            component="docker",
            message="Docker configuration exists but Docker is unavailable.",
            recommendation="Install Docker or make the Docker CLI available on PATH.",
        ))

    if not git.is_repository:
        issues.append(DiagnosticIssue(
            type="git_repository_missing",
            severity="low",
            component="git",
            message="Project is not a Git repository.",
            recommendation="Initialize or open the project from its Git repository if version control is expected.",
        ))

    facts = {
        "system": get_system_info().model_dump(),
        "project": project.model_dump(),
        "runtimes": {k: v.model_dump() for k, v in runtimes.items()},
        "git": git.model_dump(),
    }
    return EnvironmentDiagnosis(healthy=not issues, facts=facts, issues=issues)
