"""
Application configuration.

Loads settings from environment variables (via a .env file in local
development). Nothing sensitive is ever exposed to the frontend --
this module is backend-only.
"""
import os
from dotenv import load_dotenv

load_dotenv()


class Settings:
    # LLM configuration (optional -- app still works without it)
    LLM_API_KEY: str | None = os.getenv("LLM_API_KEY") or None
    LLM_BASE_URL: str | None = os.getenv("LLM_BASE_URL") or None
    LLM_MODEL: str = os.getenv("LLM_MODEL", "claude-sonnet-4-6")

    # Timeouts (seconds)
    FETCH_TIMEOUT: int = int(os.getenv("FETCH_TIMEOUT", "30"))
    AGENT_TIMEOUT: int = int(os.getenv("AGENT_TIMEOUT", "60"))

    # MCP fetch server launch command. "uvx" runs the published
    # mcp-server-fetch package without a separate install step.
    MCP_FETCH_COMMAND: str = os.getenv("MCP_FETCH_COMMAND", "uvx")
    MCP_FETCH_ARGS: list[str] = os.getenv("MCP_FETCH_ARGS", "mcp-server-fetch").split()

    @property
    def llm_configured(self) -> bool:
        return bool(self.LLM_API_KEY)


settings = Settings()
