import json
from services.package_service import get_node_packages

def test_node_packages(tmp_path):
    (tmp_path / "package.json").write_text(json.dumps({"dependencies":{"react":"^19"},"devDependencies":{"vite":"^7"}}))
    info = get_node_packages(str(tmp_path))
    assert info.success
    assert info.dependencies["react"] == "^19"
    assert info.dev_dependencies["vite"] == "^7"
