from dataclasses import dataclass

import httpx

from src.config import settings
from src.services.robots import RobotsChecker
from src.services.security import validate_url


@dataclass
class FetchResult:
    url: str
    status_code: int
    content_type: str
    content: str
    content_length: int
    truncated: bool


class WebFetcher:
    def __init__(self, timeout: float | None = None):
        self.timeout = timeout or settings.timeout
        self.robots = RobotsChecker(timeout=self.timeout)

    async def fetch(
        self,
        url: str,
        respect_robots: bool = True,
    ) -> FetchResult:
        url = validate_url(url, settings.block_private_networks)

        if respect_robots:
            robots = await self.robots.check(url)
            if not robots["allowed"]:
                raise PermissionError(
                    f"Fetching blocked by robots.txt: {robots['reason']}"
                )

        headers = {
            "User-Agent": settings.user_agent,
            "Accept": (
                "text/html,application/xhtml+xml,application/xml;q=0.9,"
                "text/plain;q=0.8,*/*;q=0.5"
            ),
        }

        async with httpx.AsyncClient(
            timeout=self.timeout,
            follow_redirects=True,
            headers=headers,
        ) as client:
            async with client.stream("GET", url) as response:
                response.raise_for_status()

                content_type = response.headers.get("content-type", "")
                chunks: list[bytes] = []
                total = 0
                truncated = False

                async for chunk in response.aiter_bytes():
                    remaining = settings.max_content_bytes - total

                    if remaining <= 0:
                        truncated = True
                        break

                    if len(chunk) > remaining:
                        chunks.append(chunk[:remaining])
                        total += remaining
                        truncated = True
                        break

                    chunks.append(chunk)
                    total += len(chunk)

                raw_content = b"".join(chunks)
                encoding = response.encoding or "utf-8"

                try:
                    content = raw_content.decode(encoding, errors="replace")
                except LookupError:
                    content = raw_content.decode("utf-8", errors="replace")

                return FetchResult(
                    url=str(response.url),
                    status_code=response.status_code,
                    content_type=content_type,
                    content=content,
                    content_length=total,
                    truncated=truncated,
                )
