from src.services.parser import WebParser


def test_clean_text_removes_scripts_and_navigation():
    html = """
    <html>
      <head><title>Test</title></head>
      <body>
        <nav>Navigation</nav>
        <h1>Hello</h1>
        <p>This is content.</p>
        <script>alert("x")</script>
      </body>
    </html>
    """
    text = WebParser.clean_text(html)

    assert "Navigation" not in text
    assert "alert" not in text
    assert "Hello" in text
    assert "This is content." in text


def test_extract_links_returns_absolute_urls():
    html = '<a href="/docs">Docs</a><a href="https://example.org/about">About</a>'
    links = WebParser.extract_links(
        html,
        "https://example.org/",
    )

    assert links[0]["url"] == "https://example.org/docs"
    assert links[0]["text"] == "Docs"


def test_metadata():
    html = """
    <title>My Page</title>
    <meta name="description" content="A test page">
    <h1>Main</h1>
    <h2>Section</h2>
    """
    metadata = WebParser.metadata(html)

    assert metadata["title"] == "My Page"
    assert metadata["description"] == "A test page"
    assert metadata["headings"][0]["text"] == "Main"
